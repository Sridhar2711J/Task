import { useState,useRef } from 'react'
import './App.css'
import Nav from './components/Nav'
import HomePage from './components/HomePage'
import AboutPage from './components/About'
import ContactPage from './components/Contact'

function App() {

  const homeRef = useRef(null)
  const aboutRef = useRef(null)
  const contentRef = useRef(null)

  return (
    <>
    <Nav
        homeRef={homeRef}
        aboutRef={aboutRef}
        contentRef={contentRef}
      />

    <section ref={homeRef}>
      <HomePage/>
    </section>

    <section ref={aboutRef}>
      <AboutPage/>
    </section>

    <section ref={contentRef}>
      <ContactPage/>
    </section>
    </>
  )
}

export default App
