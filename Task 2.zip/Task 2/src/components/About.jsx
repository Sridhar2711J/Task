import React from 'react'
import './About.css'

function About() {
  return (
    <section className='AboutPage'>
        <div className="About-Side1">
            <h2>About Company</h2>
            <p>This is the about page.</p>
            <div className="box-contanair">
                <h3>Improvement</h3>
                <h3>Marketing</h3>
            </div>
            <button className='button'>Get Started</button>
        </div>

        <div className="About-Side2">
            <img src="images\teacher.jpg" alt="" />
        </div>
    </section>
  )
}

export default About