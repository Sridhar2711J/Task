import React from 'react'
import './HomePage.css'

function HomePage() {
  return (
    <section className='HomePage'>
    <div className="overlayer"></div>
    <div className="home-content">
        <h1>We Provide <br /> Solution On Your <br /> Business</h1>
        <p>Helping you grow with the best solutions.</p>
        <button className='button'>Get Started</button>
    </div>
    </section>
  )
}

export default HomePage