import React,{useRef} from 'react'
import './Nav.css'


function Nav({homeRef, aboutRef, contentRef}) {
   const scrollToSection = (ref) => {
    if (ref.current) {
      ref.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header className="navbar">
      <div className="logo">Tora</div>
      <nav>
        <ul>
          <li onClick={() => scrollToSection(homeRef)}>Home</li>
          <li onClick={() => scrollToSection(aboutRef)}>About</li>
          <li onClick={() => scrollToSection(contentRef)}>Contact</li>
        </ul>
      </nav>
      <button className="nav-btn">Get Started</button>
    </header>
  )
}

export default Nav