import React from 'react'
import './Contact.css'

const Contact = () => {
  return (
   <section className='ContactPage'>
         <div className="contact-contanier">
            <div className="Address">
               <p>
                <h1>Branch 1 Address:</h1>
                742 Evergreen Terrace <br /> 
                Springfield, IL 62704  <br />
                USA  <br />
                Phone: +1 (217) 555-1234 <br /> 
                Email: Tora@example.com  <br />
               </p>
            </div>
            <div className="Address">
                <p>
                <h1>Branch 2 Address:</h1>
                221B Baker Street <br /> 
                London NW1 6XE  <br />
                United Kingdom  <br />
                Phone: +44 20 7946 0958 <br />
                Email: Tora@example.com  <br />
               </p>
            </div>
         </div>

         <div className="sign-up">
            <h1>Sign-Up</h1>
            <input type="email" placeholder='Enter Your Email'/>
            <button>Submit</button>
         </div>
   </section>
  )
}

export default Contact