import TaskItem from "./TaskItem";

export default function TaskList({ tasks, deleteTask, toggleTask, editTask }) {
  return (
    <div className="task-list">
      {tasks.length === 0 && <p className="empty-text">No tasks yet. Add one!</p>}
      {tasks.map((task) => (
        <TaskItem
          key={task.id}
          task={task}
          deleteTask={deleteTask}
          toggleTask={toggleTask}
          editTask={editTask}
        />
      ))}
    </div>
  );
}
