import { useState } from "react";

export default function TaskItem({ task, deleteTask, toggleTask, editTask }) {
  const [isEditing, setIsEditing] = useState(false);
  const [text, setText] = useState(task.text);

  const handleEdit = () => {
    if (isEditing && text.trim()) {
      editTask(task.id, text);
    }
    setIsEditing(!isEditing);
  };

  return (
    <div className="task-item">
      <div className="task-left">
        <input
          type="checkbox"
          checked={task.completed}
          onChange={() => toggleTask(task.id)}
        />
        {isEditing ? (
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
        ) : (
          <span className={task.completed ? "completed" : ""}>
            {task.text}
          </span>
        )}
      </div>
      <div className="task-actions">
        <button onClick={handleEdit} className="edit-btn">
          {isEditing ? "Save" : "Edit"}
        </button>
        <button onClick={() => deleteTask(task.id)} className="delete-btn">
          Delete
        </button>
      </div>
    </div>
  );
}
